from django.conf.urls import url
from doctor import views

urlpatterns=[
    url('doc/',views.doctor),
    url('vw/',views.VWdoct),
    url('adm/',views.admin_vw)
]