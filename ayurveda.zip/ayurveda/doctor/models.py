from django.db import models

# Create your models here.
class Doctor(models.Model):
    doctor_id = models.AutoField(db_column='DOCTOR_id', primary_key=True)  # Field name made lowercase.
    doctor_name = models.CharField(db_column='Doctor_name', max_length=50)  # Field name made lowercase.
    qualification = models.CharField(db_column='Qualification', max_length=50)  # Field name made lowercase.
    doctor_phone = models.CharField(db_column='Doctor_phone', max_length=12)  # Field name made lowercase.
    doctor_email = models.CharField(db_column='Doctor_email', max_length=50)  # Field name made lowercase.
    password = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'doctor'

