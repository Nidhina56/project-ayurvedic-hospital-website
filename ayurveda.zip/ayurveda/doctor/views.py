from django.shortcuts import render
from doctor.models import Doctor
from login.models import Login
# Create your views here.
def doctor(request):
    if request.method == 'POST':
     ob=Doctor()
     ob.doctor_name=request.POST.get('name')
     ob.qualification=request.POST.get('qualification')
     ob.doctor_phone=request.POST.get('phone')
     ob.doctor_email=request.POST.get('email')
     ob.password=request.POST.get('password')
     ob.save()

     obj=Login()
     obj.user_name=ob.doctor_name
     obj.password=ob.password
     obj.type="doctor"
     obj.user_id=ob.doctor_id
     obj.save()
    return render(request,'doctor/doctor.html')

def VWdoct(request):
    doc=Doctor.objects.all()
    context={
        'x':doc
    }
    return render(request,'doctor/v_doctorlist.html',context)

def admin_vw(request):
    doc=Doctor.objects.all()
    context={
        'x':doc
    }
    return render(request,'doctor/admin_vw.html',context)