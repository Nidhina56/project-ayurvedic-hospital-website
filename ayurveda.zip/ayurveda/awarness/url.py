from django.conf.urls import url
from awarness import views

urlpatterns=[
    url('aware/',views.awarenes),
    url('view/',views.v_aware)
]