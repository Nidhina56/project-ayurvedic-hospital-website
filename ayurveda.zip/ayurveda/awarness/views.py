from django.shortcuts import render
from awarness.models import Awarness
# Create your views here.
def awarenes(request):
  if request.method=='POST':
    aw=Awarness()
    aw.awarness=request.POST.get('awarness')
    aw.save()
  return render(request,'awarness/awarness.html')
def v_aware(request):
  ob=Awarness.objects.all()
  context={
    'x':ob
  }
  return render(request,'awarness/v_awarness.html',context)