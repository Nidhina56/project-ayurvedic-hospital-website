from django.db import models

# Create your models here.
class Awarness(models.Model):
    awarness_id = models.AutoField(db_column='Awarness_id', primary_key=True)  # Field name made lowercase.
    awarness = models.CharField(db_column='Awarness', max_length=100)  # Field name made lowercase.
    # date = models.DateField(db_column='Date')  # Field name made lowercase.
    # time = models.TimeField(db_column='Time')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'awarness'
