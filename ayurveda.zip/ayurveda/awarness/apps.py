from django.apps import AppConfig


class AwarnessConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'awarness'
