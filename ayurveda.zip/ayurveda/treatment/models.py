from django.db import models

# Create your models here.
class Treatment(models.Model):
    treatment_id = models.AutoField(db_column='Treatment_id', primary_key=True)  # Field name made lowercase.
    treatment = models.CharField(db_column='Treatment', max_length=100)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'treatment'
