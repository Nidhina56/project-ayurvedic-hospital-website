from django.shortcuts import render
from treatment.models import Treatment
# Create your views here.
def treat(request):
    if request.method=="POST":
        tr=Treatment()
        tr.treatment=request.POST.get('TREATMENT')
        tr.save()
    return render(request,'treatment/TREATMENT.HTML')

def treatment(request):
    tr=Treatment.objects.all()
    context={
        'x':tr

    }
    return render(request,'treatment/v_treatment.html',context)