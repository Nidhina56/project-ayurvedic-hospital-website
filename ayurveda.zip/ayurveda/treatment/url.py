from django.conf.urls import url
from treatment import views

urlpatterns=[
    url('treat/',views.treatment),
    url('treatment/',views.treat)
]