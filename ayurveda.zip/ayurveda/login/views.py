from django.shortcuts import render
from login.models import Login
# Create your views here.

def login(request):
    if request.method=='POST':
        uname=request.POST.get("uname")
        passw=request.POST.get("password")
        obj=Login.objects.filter(user_name=uname,password=passw)
        tp=""
        for ob in obj:
            tp=ob.type
            uid=ob.user_id
            if tp=="admin":
                request.session['uid']=uid
                return render(request,'temp/admin.html')
            elif tp=="doctor":
                request.session['uid']=uid
                return render(request,'temp/doctor.html')
            elif tp=="patient":
                request.session['uid']=uid
                return render(request,'temp/patient.html')
        objlist="user name or password is incorrect......"
        context={
            'x':objlist
        }
        return render(request,'login/login.html',context)


    return render(request,"login/login.html")
