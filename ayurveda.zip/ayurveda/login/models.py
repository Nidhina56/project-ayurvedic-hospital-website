from django.db import models

# Create your models here.

class Login(models.Model):
    login_id = models.AutoField(db_column='Login_id', primary_key=True)  # Field name made lowercase.
    user_name = models.CharField(db_column='User Name', max_length=50)  # Field name made lowercase. Field renamed to remove unsuitable characters.
    password = models.CharField(db_column='Password', max_length=12)  # Field name made lowercase.
    user_id = models.IntegerField(db_column='User_id')  # Field name made lowercase.
    type = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'login'
