from django.db import models



class PatientDetails(models.Model):
    patient_id = models.AutoField(primary_key=True)
    patient_name = models.CharField(max_length=50)
    patient_age = models.IntegerField()
    patient_phone_no = models.CharField(db_column='patient_phone no', max_length=12)  # Field renamed to remove unsuitable characters.
    patient_address = models.CharField(max_length=100)
    password = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'patient_details'
