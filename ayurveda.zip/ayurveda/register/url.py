from django.conf.urls import url
from register import views

urlpatterns=[
    url('reg/',views.reg),
    url('view/',views.vw),
    url('patient/',views.dr_vw)
]