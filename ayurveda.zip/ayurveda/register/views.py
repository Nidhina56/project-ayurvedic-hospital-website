from django.shortcuts import render
from register.models import PatientDetails
from login.models import Login

def reg(request):
    if request.method=="POST":
        obj=PatientDetails()
        obj.patient_name=request.POST.get('NAME')
        obj.patient_address=request.POST.get('ADDRESS')
        obj.patient_age=request.POST.get('AGE')
        obj.patient_phone_no=request.POST.get('phone')
        obj.password=request.POST.get('password')
        obj.save()

        ob=Login()
        ob.user_name=obj.patient_name
        ob.password=obj.password
        ob.type="patient"
        ob.user_id=obj.patient_id
        ob.save()
    return render(request,'register/register.html')

def vw(request):
    obje=PatientDetails.objects.all()
    context={
        'x':obje
    }
    return render(request,'register/PATIENT.HTML',context)



def dr_vw(request):
    obje=PatientDetails.objects.all()
    context={
        'x':obje
    }
    return render(request,'register/dr_vw_pt.html',context)

