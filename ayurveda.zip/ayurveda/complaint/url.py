from django.conf.urls import url
from complaint import views

urlpatterns=[
    url('comp/',views.complaint),
    url('complaints/',views.complan),
    url('reply/(?P<idd>\w+)',views.reply,name='rep'),
    url('vw/',views.rpy)
]