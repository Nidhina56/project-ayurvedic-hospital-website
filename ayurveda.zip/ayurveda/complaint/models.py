from django.db import models

# Create your models here.
class ComplaintAndReply(models.Model):
    complaint_id = models.AutoField(db_column='Complaint_id', primary_key=True)  # Field name made lowercase.
    complaint = models.CharField(db_column='Complaint', max_length=100)  # Field name made lowercase.
    reply = models.CharField(db_column='Reply', max_length=100)  # Field name made lowercase.
    user_id = models.IntegerField(db_column='User_id')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'complaint_and_reply'
