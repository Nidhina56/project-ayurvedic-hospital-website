from django.shortcuts import render
from complaint.models import ComplaintAndReply
# Create your views here.
def complaint(request):
    ss=request.session['uid']
    if request.method=='POST':
        obj=ComplaintAndReply()
        obj.complaint=request.POST.get('COMPLAIN')
        obj.user_id=ss
        obj.save()
    return render(request,'complaint/complaint.html')


def complan(request):
    com=ComplaintAndReply.objects.all()
    context={
        'x':com
    }
    return render(request,'complaint/v_complain.html',context)
def rpy(request):
    ss=request.session['uid']
    com=ComplaintAndReply.objects.filter(user_id=ss)
    context={
        'x':com
    }
    return render(request,'complaint/view_rply.html',context)

def reply(request,idd):
    ab=ComplaintAndReply.objects.get(complaint_id=idd)
    ab.reply=request.POST.get('reply')
    ab.save()
    return render(request,'complaint/reply.html')

