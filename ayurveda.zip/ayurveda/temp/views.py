from django.shortcuts import render

# Create your views here.

def home(request):
    return render(request,'temp/home.html')

def admin(request):
    return render(request,'temp/admin.html')

def doctor(request):
    return render(request,'temp/doctor.html')

def patient(request):
    return render(request,'temp/patient.html')