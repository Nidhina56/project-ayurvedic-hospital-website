from django.shortcuts import render
from disease.models import Disease

# Create your views here.
def disease(request):
    if request.method == 'POST':
     di=Disease()
     di.disease_name=request.POST.get('NAME')
     di.medicine='1'
     di.save()
    return render(request,'disease/DIEASE.HTML')

def dis(request):
    dise=Disease.objects.all()
    context={
        'x':dise
    }
    return render(request,'disease/v_diease.html',context)