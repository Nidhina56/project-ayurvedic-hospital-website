from django.db import models

# Create your models here.
class Disease(models.Model):
    disease_id = models.AutoField(db_column='Disease_id', primary_key=True)  # Field name made lowercase.
    disease_name = models.CharField(db_column='Disease_name', max_length=50)  # Field name made lowercase.
    medicine = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'disease'
