from django.conf.urls import url
from disease import views

urlpatterns=[
    url('dis/',views.disease),
    url('dise/',views.dis)
]