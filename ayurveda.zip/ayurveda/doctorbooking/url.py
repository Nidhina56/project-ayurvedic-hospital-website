from django.conf.urls import url
from doctorbooking import views

urlpatterns=[
    url('doctor/',views.doc),
    url('booking/(?P<idd>\w+)',views.booking),
    url('ap/(?P<idd>\w+)',views.approve),
    url('rj/(?P<idd>\w+)',views.reject),
    url('vw_dr/',views.dr_vw),
    url('vwpatient/',views.view_patient)

]