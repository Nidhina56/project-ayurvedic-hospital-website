from django.db import models
from doctor.models import Doctor
# Create your models here.
class DoctorBooking(models.Model):
    booking_id = models.AutoField(db_column='Booking_id', primary_key=True)  # Field name made lowercase.
    # doctor_id = models.IntegerField(db_column='Doctor_id')  # Field name made lowercase.
    doctor=models.ForeignKey(Doctor, to_field='doctor_id', on_delete=models.CASCADE)
    booking_time = models.TimeField()
    booking_date = models.DateField()
    user_id = models.IntegerField()
    status = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'doctor_booking'
