from django.shortcuts import render
from doctorbooking.models import DoctorBooking
from doctor.models import Doctor
# Create your views here.
def doc(request):
    doct=DoctorBooking.objects.all()
    context={
        'x':doct
    }
    return render(request,'doctorbooking/v_doctorbooking.html',context)

def booking(request,idd):
    ss=request.session['uid']
    ob=Doctor.objects.all()
    context={
        'y':ob
    }
    if request.method=='POST':
        obj=DoctorBooking()
        obj.doctor_id=idd
        obj.user_id=ss
        obj.booking_date=request.POST.get('date')
        obj.booking_time=request.POST.get('time')
        obj.status="pending"
        obj.save()
    return render(request,'doctorbooking/booking.html',context)

def approve(request,idd):
    obj=DoctorBooking.objects.get(booking_id=idd)
    obj.status="Approved"
    obj.save()
    return doc(request)
def reject(request,idd):
    obj=DoctorBooking.objects.get(booking_id=idd)
    obj.status="reject"
    obj.save()
    return doc(request)

def dr_vw(request):
    obj=DoctorBooking.objects.get(status="Approved")
    context = {
        'x': obj
    }
    return render(request,'doctorbooking/doctor_view.html',context)
def view_patient(request):
    obj=DoctorBooking.objects.all()
    context ={
        'x':obj
    }
    return render(request,'doctorbooking/vwpatient.html',context)


