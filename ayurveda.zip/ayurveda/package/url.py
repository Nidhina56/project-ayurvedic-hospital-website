from django.conf.urls import url
from package import views

urlpatterns=[
    url('pack/',views.package),
    url('vw/',views.vw_pack)
]