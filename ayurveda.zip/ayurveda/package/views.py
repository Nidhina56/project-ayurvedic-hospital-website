from django.shortcuts import render
from package.models import Package
# Create your views here.
def package(request):
    if request.method == 'POST':
        pk=Package()
        pk.package=request.POST.get('PACKAGE')
        pk.paymet=request.POST.get('PAYMENT')
        pk.save()
    return render(request, 'package/package.html')



def vw_pack(request):
    ob=Package.objects.all()
    context={
        'x':ob
    }
    return render(request,'package/view_package.html',context)
