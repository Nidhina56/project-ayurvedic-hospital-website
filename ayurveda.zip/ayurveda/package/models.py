from django.db import models

# Create your models here.
class Package(models.Model):
    package_id = models.AutoField(db_column='Package_id', primary_key=True)  # Field name made lowercase.
    package = models.CharField(db_column='Package', max_length=100)  # Field name made lowercase.
    paymet = models.IntegerField(db_column='Paymet')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'package'
